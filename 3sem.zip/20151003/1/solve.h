#include "student_list.h"

int count_different_elements (student_list *head);
