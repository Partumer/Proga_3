#include "student_list.h"

int generate (student_list *, int n);
