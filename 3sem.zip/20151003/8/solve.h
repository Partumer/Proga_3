#include "student_list.h"

int max_distance (student_list *head);
