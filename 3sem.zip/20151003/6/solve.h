#include "student_list.h"

int get_max_length_of_increase (student_list *head);
