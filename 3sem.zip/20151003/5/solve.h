#include "student_list.h"

int type_of_list (student_list *head);
