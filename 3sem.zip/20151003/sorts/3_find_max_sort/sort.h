#include "student_list.h"

void find_sort (student_list *head, int n);
