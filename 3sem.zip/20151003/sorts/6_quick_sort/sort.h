#include "student_list.h"

void quick_sort (student_list *head, student_node *first, student_node *last, student_node *prev);
