#include "student_list.h"

void bubble_sort (student_list *head);
