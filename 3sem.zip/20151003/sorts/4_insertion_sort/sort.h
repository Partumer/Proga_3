#include "student_list.h"

void insertion_sort (student_list *head);
