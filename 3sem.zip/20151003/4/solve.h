#include "student_list.h"

int count_local_maximums (student_list *head);
