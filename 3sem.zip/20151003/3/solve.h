#include "student_list.h"

int count_elements (student_list *head);
