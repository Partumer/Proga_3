#include "student_list.h"

int number_of_constant_sites (student_list *head);
