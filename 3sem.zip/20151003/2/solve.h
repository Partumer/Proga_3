#include "student_list.h"

int count_max_elements (student_list *head);
