#include "student_list.h"

int read_list (const char *, student_list *head);
void print_list (student_list *, int n);
void return_error (int result, const char * file_name);
