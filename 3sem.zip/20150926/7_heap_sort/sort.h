#include "student.h"

void heapsorted (student *array,
                 int length);
void sift_up (student *binary_tree, 
		      int position);
void sift_down (student *binary_tree,
                int position, 
                int length);
