#include "student.h"

void binary_insertion_sort(student *, int); 
int binsearch(student *array,
	      int length,
	      student *new_element);
