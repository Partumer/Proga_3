int generate (student *array, int n);
