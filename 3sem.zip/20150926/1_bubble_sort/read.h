#include "student.h"

int read_array (const char *, student *, int);
void print_array (student *, int);
