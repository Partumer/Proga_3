#include "student.h"

int merge_sort(student *,
               student *,
               int);
void merge(student *,
           student *,
           int,
           int,
           student *);
