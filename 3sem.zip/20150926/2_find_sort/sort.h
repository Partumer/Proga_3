#include "student.h"

void find_sort(student *, int); 
