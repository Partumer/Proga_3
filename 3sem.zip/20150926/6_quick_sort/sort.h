#include "student.h"

void quick_sort(student *array,
                int length);
