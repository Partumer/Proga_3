#include "student.h"

void insertion_sort(student *, int); 
