#include "stack.h"

int generate_file (const char *filename, int n);
