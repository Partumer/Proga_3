#include "stack.h"

void return_error (int result, const char *file_name);
