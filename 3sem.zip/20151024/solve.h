#include "student_list.h"

student_list *make_new_list1 (student_list *head, student *element, int *n);
student_list *delete_less2 (student_list *head, int *n);
student_list *delete_equal3 (student_list *head, int *n);
student_list *delete_more4 (student_list *head, student *element, int *n);
student_list *delete_increasing5 (student_list *head, int *n);
student_list *delete_6 (student_list *head, student *element, int *n);
